=== Custom Trustpilot Reviews ===
Contributors: Nelson Gil
Tags: Trustpilot, reviews, Divi, ratings
Requires at least: 5.6
Tested up to: 6.4
Requires PHP: 7.4
Stable tag: 1.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

== Description ==
Muestra las valoraciones de Trustpilot en WordPress y Divi con un diseño personalizable.

== Installation ==
1. Subir plugin.
2. Examinar, busca el archivo y seleccionalo.
3. Instalar ahora.
4. Activa el plugin desde el panel de administración de WordPress.

== Screenshots ==
1. assets/img/logo.webp

== Plugin Icon ==
assets/img/logo.webp
